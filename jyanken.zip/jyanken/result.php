<?php
//var_dump($_POST);
//誤ってGETでアクセスされたら最初の画面に送り返す
if($_SERVER['REQUEST_METHOD'] == "GET"){
    header("location: ./gamestart.html");
    exit;
}
//POSTで送らて来た値はstringのためintに変換
$myhand = intval($_POST["myhand"]);//"0" "1"
$janken_array = array("グー","チョキ","パー");
//コンピューターの手は乱数で生成
$pchand = rand(0,2);

//関数定義
function showhand(int $hand):string{
    $janken_array = array("グー","チョキ","パー");
    return $janken_array[$hand];
}

?>
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>じゃんけんゲーム結果</title>
</head>
<body>
    <h1>じゃんけんゲーム結果</h1>
    <ul>
        <li>自分の手：<?=showhand($myhand)?></li><!--showhand($myhand)-->
        <li>コンピューターの手：<?=showhand($pchand)?></li>
        <li>勝敗：</li>
    </ul>
    <p><a href="gamestart.html">戻る</a></p>
</body>
</html>